
package com.lgcns.vpadmin.intent;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Test {

    public static void main(String[] args) {
        List<Person> persons = Arrays.asList(
                new Person("e1", "l1"),
                new Person("e2", "l1"),
                new Person("e3", "l2"),
                new Person("e4", "l2")
        );

        List<Employee> employees = persons.stream()
                .filter(p -> p.getLastName().equals("l1"))
                .map(p -> new Employee(p.getName(), p.getLastName(), 1000))
                .collect(Collectors.toList());

        System.out.println(employees);
        employees.forEach(item->System.out.println(item));
        
        System.out.println("===================forEach and Map=====================");
        Map<String, Integer> mapIitems = new HashMap<>();
        mapIitems.put("A", 10);
        mapIitems.put("B", 20);
        mapIitems.put("C", 30);
        mapIitems.put("D", 40);
        mapIitems.put("E", 50);
        mapIitems.put("F", 60);

    	for (Map.Entry<String, Integer> entry : mapIitems.entrySet()) {
    		System.out.println("mapIitems:" + entry.getKey() + " Count : " + entry.getValue());
    	}
    	System.out.println("=============java8 version===========================");
    	Map<String, Integer> items = new HashMap<>();
    	items.put("A", 10);
    	items.put("B", 20);
    	items.put("C", 30);
    	items.put("D", 40);
    	items.put("E", 50);
    	items.put("F", 60);
    	
    	items.forEach((k,v)->System.out.println("Item : " + k + " Count : " + v));
    	
    	items.forEach((k,v)->{
    		System.out.println("Item : " + k + " Count : " + v);
    		if("E".equals(k)){
    			System.out.println("Hello E");
    		}
    	});
        System.out.println("==================forEach and List======================");
        List<String> items1 = new ArrayList<>();
        items1.add("A");
        items1.add("B");
        items1.add("C");
        items1.add("D");
        items1.add("E");

    	for(String item : items1){
    		System.out.println(item);
    	}
    	System.out.println("=============java8 version===========================");
    	
    	List<String> items2 = new ArrayList<>();
    	items2.add("A");
    	items2.add("B");
    	items2.add("C");
    	items2.add("D");
    	items2.add("E");

    	//lambda
    	//Output : A,B,C,D,E
    	items2.forEach(item->System.out.println(item));
    		
    	//Output : C
    	items2.forEach(item->{
    		if("C".equals(item)){
    			System.out.println(item);
    		}
    	});
    		
    	//method reference
    	//Output : A,B,C,D,E
    	items2.forEach(System.out::println);
    	
    	//Stream and filter
    	//Output : B
    	items2.stream()
    		.filter(s->s.contains("B"))
    		.forEach(System.out::println);

        System.out.println("========================================");
    }

}

class Person {

    private String name;
    private String lastName;

    public Person(String name, String lastName) {
        this.name = name;
        this.lastName = lastName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}

class Employee extends Person {

    private double salary;

    public Employee(String name, String lastName, double salary) {
        super(name, lastName);
        this.salary = salary;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

}