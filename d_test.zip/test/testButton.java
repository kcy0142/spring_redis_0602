


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class Button {

	private static final long serialVersionUID = 4220461820168818969L;

	/**
	 * 버튼유형
	 */
	private String type;

	/**
	 * 버튼 제목
	 */
	private String title;

	// 액션정보

	/**
	 * 액션 유형 (link: 링크, inquiry: 인텐트처리)
	 */
	private String actionType;

	/**
	 * 액션 connect 유형 (pc: pc, mobile: mobile)
	 */
	private String actionConnectType;

	/**
	 * 액션
	 */
	private String action;

	/**
	 * 액션 파라미터
	 */
	private Map<String, Object> actionParams;

	/**
	 * 아이콘 (Font Awesome class)
	 */
	private String icon;

	private int popupWidth;

	private int popupHeight;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getAction() {
		return action;
	}

	public Map<String, Object> getActionParams() {
		return actionParams;
	}

	public void setActionParams(Map<String, Object> actionParams) {
		this.actionParams = actionParams;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public int getPopupWidth() {
		return popupWidth;
	}

	public void setPopupWidth(int popupWidth) {
		this.popupWidth = popupWidth;
	}

	public int getPopupHeight() {
		return popupHeight;
	}

	public void setPopupHeight(int popupHeight) {
		this.popupHeight = popupHeight;
	}

	public String getActionConnectType() {
		return actionConnectType;
	}

	public void setActionConnectType(String actionConnectType) {
		this.actionConnectType = actionConnectType;
	}
}

class Element {
	private String type;
	private String id;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}

class Attachment {

	private String attachId;
	private String attachName;

	private List<Element> elements;

	public String getAttachId() {
		return attachId;
	}

	public void setAttachId(String attachId) {
		this.attachId = attachId;
	}

	public String getAttachName() {
		return attachName;
	}

	public void setAttachName(String attachName) {
		this.attachName = attachName;
	}

	public List<Element> getElements() {
		return elements;
	}

	public void setElements(List<Element> elements) {
		this.elements = elements;
	}

}

class Activity {

	private String replyToId;
	private String tempId;
	private String type;
	private Map<String, Object> additionalProperties;
	private List<Attachment> attachments;
	/**
	 * 버튼 리스트
	 */
	private List<Button> buttons;

	public String getReplyToId() {
		return replyToId;
	}

	public void setReplyToId(String replyToId) {
		this.replyToId = replyToId;
	}

	public String getTempId() {
		return tempId;
	}

	public void setTempId(String tempId) {
		this.tempId = tempId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Map<String, Object> getAdditionalProperties() {
		return additionalProperties;
	}

	public void setAdditionalProperties(Map<String, Object> additionalProperties) {
		this.additionalProperties = additionalProperties;
	}

	public Activity addAdditionalProperty(String key, Object value) {
		if (this.additionalProperties == null) {
			this.additionalProperties = new HashMap<>();
		}
		this.additionalProperties.put(key, value);
		return this;
	}

	public List<Attachment> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<Attachment> attachments) {
		this.attachments = attachments;
	}

	// BUTTON START
	public List<Button> getButtons() {
		return buttons;
	}

	public void setButtons(List<Button> buttons) {
		this.buttons = buttons;
	}

	public Activity addButton(Button button) {
		if (this.buttons == null) {
			this.buttons = new ArrayList<Button>();
		}
		this.buttons.add(button);
		return this;
	}

	public Activity addButton(int position, Button button) {
		if (this.buttons == null) {
			this.buttons = new ArrayList<Button>();
		}

		position = (position >= this.buttons.size()) ? this.buttons.size() : position;
		position = (position < 0) ? 0 : position;

		this.buttons.add(position, button);
		return this;
	}
	// BUTTON END

}

class Article {
	int seq; // 글 번호
	String subject; // 글 제목
	String writer; // 작성자

	public Article(int seq, String subject, String writer) {
		this.seq = seq;
		this.subject = subject;
		this.writer = writer;
	}

	public void print() {
		System.out.println(this.seq);
		System.out.println(this.subject);
		System.out.println(this.writer);
	}
}

public class TestButton {

	public static List<Button> addLikeButton(List<Button> activityButtonList, String actionConnectType) {

		List<Button> resultList = new ArrayList<Button>();

		if ((activityButtonList != null) && (!activityButtonList.isEmpty())) {

			for (Button button : activityButtonList) {
				resultList.add(button);
			}
		}

		Button likeButton = new Button();
		likeButton.setType("like");
		likeButton.setActionType("like Button");
		likeButton.setAction("like action");

		resultList.add(likeButton);

		Button dislikeButton = new Button();
		dislikeButton.setType("dislike");
		dislikeButton.setActionType("dislike Button");
		dislikeButton.setAction("dislike action");

		resultList.add(dislikeButton);

		return resultList;
	}

	public static void main(String[] args) {

		Article article1 = new Article(1, "자바연습", "감성공대생");
		article1.print();
		System.out.println("-------------");
		Article article2 = new Article(2, "자바는 쉽다", "감공");
		article2.print();

		Map<String, Object> additionalProperties = new HashMap<>();
		additionalProperties.put("name", "james");
		additionalProperties.put("age", "43");

		Activity activity = new Activity();
		activity.setTempId("11111");
		activity.setAdditionalProperties(additionalProperties);

		activity.addAdditionalProperty("title", "title");
		activity.addAdditionalProperty("content", "content");

		System.out.println("-----activity.getTempId--------" + activity.getTempId());
		System.out.println("-----activity.getAdditionalProperties--------" + activity.getAdditionalProperties());

		Attachment attachment = new Attachment();
		attachment.setAttachId("1");
		attachment.setAttachName("name1");
		List<Attachment> attachments = new ArrayList<>();
		// attachments.set(0, attachment);

		attachments.add(0, attachment);

		// activity.setAttachments(attachments);

		// System.out.println("----activity.getAttachments---------"+activity.getAttachments().size());

		System.out.println("----activity Button----");

		List<Button> buttonList = new ArrayList<Button>();
		Map<String, Object> addButton = new HashMap<>();
		addButton.put("width", "100");
		addButton.put("height", "43");

		Button button = new Button();
		button.setActionConnectType("mobile");
		button.setActionType("type");
		button.setAction("action");
		button.setTitle("title");
		button.setActionParams(addButton);

		buttonList.add(button);

		buttonList.stream().forEach(s -> {

			System.out.println("#### button1:" + s.getActionParams());

		});

		System.out.println("----activity Button Test----");
		Activity activityResult = new Activity();
		List<Button> newButtons = addLikeButton(buttonList, "mobile");
		if (newButtons != null) {
			activityResult.setButtons(newButtons);
		}

		activityResult.getButtons().stream().forEach(s -> {
			System.out.println("#### button2:" + s.getActionType());
		});

		System.out.println("----activity Button New Test----");
		Activity activityNew=new Activity();
		
		//button set으로 List 타입을 저장 시작
		List<Button> activityButtonList = new ArrayList<Button>();
		Map<String, Object> addButton3 = new HashMap<>();
		addButton3.put("width", "50");
		addButton3.put("height", "51");

		Button button3 = new Button();
		button3.setActionConnectType("pc");
		button3.setActionType("actionType3");
		button3.setAction("action3");
		button3.setTitle("title3");
		button3.setActionParams(addButton3);
		activityButtonList.add(button3);
		
		activityNew.setButtons(activityButtonList);
		//button set으로 List 타입을 저장 끝
				
		Map<String, Object> addButton1 = new HashMap<>();
		addButton1.put("width", "100");
		addButton1.put("height", "43");

		Button button1 = new Button();
		button1.setActionConnectType("mobile1");
		button1.setActionType("type1");
		button1.setAction("action1");
		button1.setTitle("title1");
		button1.setActionParams(addButton1);
		
		activityNew.addButton(button1);
		
		Map<String, Object> addButton2 = new HashMap<>();
		addButton2.put("width", "100111");
		addButton2.put("height", "43111");

		Button button2 = new Button();
		button2.setActionConnectType("mobile2");
		button2.setActionType("type2");
		button2.setAction("action2");
		button2.setTitle("title2");
		button2.setActionParams(addButton2);
		
		activityNew.addButton(button2);
		
		List<Button> newButtons2 = addLikeButton(activityNew.getButtons(), "mobile");
		if (newButtons2 != null) {
			activityNew.setButtons(newButtons2);
		}
		
		activityNew.getButtons().stream().forEach(s -> {
			System.out.println("#### buttonList:" + s.getActionType());
		});
		
	}

}
