

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class stringMapperTest {
	
	private final String START_KEY = "{$", END_KEY = "$}", MAPPER_PATH = "mappers", MESSAGE_PATH = "appendMessage", RESULT_COUNT_KEY="{$SYSTEM_RESULT_COUNT$}";
	
	
	/**
	 * data 의 null 유무를 검사하고 
	 * @param data
	 * @return
	 */
	 public static  String convertToString (Object data) {
		
		if (data == null) {
			return null;
		}
		
		String result = null;
		
		if ( data instanceof String ) {
			result = (String) data;
		}
		else if (data instanceof Integer) {
			Integer tmp = (Integer) data;
			result = tmp.toString();
		}
		else if (data instanceof Long) {
			Long tmp = (Long) data;
			result = tmp.toString();
		}
		else if (data instanceof Float) {
			Float tmp = (Float) data;
			result = tmp.toString();
		}
		else if (data instanceof Double) {
			Double tmp = (Double) data;
			result = tmp.toString();
		}
		else {
			result = data.toString();
		}
		
		return result;
	}
	
	/**
	 * Element Action 중에서 변환해야할 변수를 실 데이터로 변환함<br/>
	 * (ex> ${AAA} 자산입니다.  ==> 1234567 자산입니다.), 단 AAA가 parameter data에 1234567로 정의되어 있어야 함.
	 * @param action
	 * @param data
	 * @return
	 */
	 public static  String makeActionValue_12 (String action, Map<String, Object> data) {
		
		if ( !StringUtils.hasText(action) || (data == null) || (data.isEmpty()) ) {
			return action;
		}
		
		String newAction = action;
		
		int sPos = action.indexOf("${");
		int ePos = -1;
		
		String key = null, keyTemp = null;
		Object value = null;
		
		while (sPos > -1) {
			ePos = action.indexOf("}", sPos);
			
			if ( (ePos <= -1) || (sPos <= -1) ) {
				break;
			}
			else {
				//keyList.add(action.substring(sPos, ePos+1));
				key = action.substring(sPos, ePos+1);
				if ( StringUtils.hasText(key) && (key.length() > 3) ) {
					keyTemp = key.substring(2, key.length()-1);
					keyTemp = keyTemp.trim();
					
					value = data.get(keyTemp);
					//System.out.println("["+keyTemp+"],["+value+"]");
					
					if (value != null) {
						newAction = newAction.replace(key, value.toString());
					}
				}
				
				sPos = action.indexOf("${", sPos+1);
			}
		}
		
		System.out.println("==="+newAction+"===");
		return newAction;
	}
	
	/**
	 * Mapper 에 설정 정보에 따라 Map 에서 값을 조회하여 Element 값을 만듬
	 * @param data
	 * @param strData
	 * @return
	 */
	 public static  String stringMapper ( Map<String, Object> data, String strData ) {
		//####data:{전월=102, 누적=100, 당월=101}
 		//####strData:투입률은 누적 : {$누적$}%, 당월 : {$당월$}%, 전월 : {$전월$}% 입니다.
		String resultStr = new String(strData);
		List<String> keyList = new ArrayList<String>();
				
		int limitPos = strData.length()-1;
		int startPos = 0, endPos = 0;
		
		//Key 값을 가져옴
		while (true) {
			startPos = strData.indexOf("{$", startPos);
			
			if (startPos < 0) {
				break;
			}
			else {
				endPos = strData.indexOf("$}", startPos);
				
				if ( (endPos < 0) || (endPos+1 > limitPos) ) {
					break;
				}
				else {
					String temp = (endPos+1 == limitPos) ? strData.substring(startPos) : strData.substring(startPos, endPos+2);
					keyList.add(temp);
					startPos = endPos;
				}
			}
		}
		
		//strData mapping
		if ( !keyList.isEmpty() ) {
			String mapValue = null;
			String mapKey = null;
			for ( String key : keyList ) {
				mapKey = key.substring(2, key.length()-2).trim();
				
				if ( StringUtils.isEmpty(mapKey) || !data.containsKey(mapKey) ) {
					//값이 없는 경우 빈문자열로 처리함
					resultStr = resultStr.replace(key,"");
					strData = strData.replace(key,"");
				}
				else {
					mapValue = convertToString( data.get(mapKey) );
					
					if ( !StringUtils.isEmpty(mapValue) ) {
						resultStr = resultStr.replace(key, mapValue);
					} else {//값이 없는 경우 빈문자열로 처리함
						resultStr = resultStr.replace(key,"");
						strData = strData.replace(key,"");
					}
				}
			}
		}
		else {
			resultStr = (data.get(strData) != null) ?  convertToString(data.get(strData)) : "";
		}
		
		return ( (resultStr == null) || (resultStr.length() <= 0) ) ? strData : resultStr;
	}
	
	public static void main(String[] args) {
		
		
		String str1 = "Hello ${myKey1}, welcome to Stack Overflow. Have a nice ${myKey2}";
	    Map<String, String> map1 = new HashMap<String, String>();
	    map1.put("myKey1", "DD84");
	    map1.put("myKey2", "day");
	    for (Map.Entry<String, String> entry : map1.entrySet()) {
	        str1 = str1.replace("${" + entry.getKey() + "}", entry.getValue());
	    }
	    System.out.println("#####new:"+str1);  
	    
	    System.out.println("#######################");
	    
	    String str = "투입률은 누적 : {$누적$}%, 당월 : {$당월$}%, 전월 : {$전월$}% 입니다.";
	    Map<String, String> map = new HashMap<String, String>();
	    map.put("누적", "100");
	    map.put("당월", "101");
	    map.put("전월", "102");
	    for (Map.Entry<String, String> entry : map.entrySet()) {
	        str = str.replace("{$" + entry.getKey() + "$}", entry.getValue());
	    }
	    System.out.println("#####new test:"+str);
	    
	    System.out.println("#######################");
	    
		List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>();
		
		Map<String, Object> item1 = new HashMap<>();
		item1.put("누적", "100");
		item1.put("당월", "101");
		item1.put("전월", "102");
		 
		dataList.add(item1);
		
			
		
		String jsonMapper="{\"mappers\":[ "
				+ "		{ "
				+ "			\"title\":\"투입률은 누적 : {$누적$}%, 당월 : {$당월$}%, 전월 : {$전월$}% 입니다.\",  "
				+ "			\"subtitle\":\"[개인투입률]\",   "
				+ "			\"actionType\":\"INQUIRY\"   "
				+ "		} "
				+ "	]  "
				+ " }";
				
		try {			
			ObjectMapper mapper = new ObjectMapper();
	        JsonNode root = mapper.readTree(jsonMapper); // <=== Json String 으로 대체
	        JsonNode node = root.path("mappers");
	        
	        String titleData = node.get(0).path("title").asText();
	        Map<String, Object> data = null;
	        int size = dataList.size();
	        for (int i = 0; i < size; i++) {
        		
        		data = dataList.get(i);
        		String result=stringMapper(data, titleData);
        		System.out.println("####data:"+data);
        		System.out.println("####titleData:"+titleData);
        		System.out.println("####result:"+result);
        		//####data:{전월=102, 누적=100, 당월=101}
        		//####titleData:투입률은 누적 : {$누적$}%, 당월 : {$당월$}%, 전월 : {$전월$}% 입니다.
        		//####result:투입률은 누적 : 100%, 당월 : 101%, 전월 : 102% 입니다.
        		
	        }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
}

