import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.springframework.util.StringUtils;

public class parameterValidatorTester {

 
 public static Map<String, Object> parameterRestValidatorTest (final String uriData, Map<String, Object> actionParam) {
  
  if (StringUtils.isEmpty(uriData)) {
   return actionParam;
  }
  
  Map<String, Object> newParams = new HashMap<String, Object>();
  boolean isExistParams = ( (actionParam == null) || (actionParam.isEmpty()) ) ? false : true; 
  String tmp = null;
  Object objTmp = null;
  Set<String> keySet = actionParam.keySet();
  
  for (String key : keySet) {
   System.out.println("##### key:"+key+",value:"+ actionParam.get(key));
   String keyParam="${"+key+"}";
   objTmp = actionParam.get(key);
   if ( isExistParams && (objTmp != null) ) {
    newParams.put(keyParam, actionParam.get(key));
   }else{
    newParams.put(keyParam, "");
   }
  }
  
  System.out.println("######parameterValidator last RESULT:"+newParams);
  return newParams;
  
 }//getParameter
 public static void main(String[] args) {
  
  
  String url="https://naver.com?target=en&q=${acctNm}&userName=${toUserName}";
  Map<String, Object> newParams = new HashMap<String, Object>();
  newParams.put("acctNm", "현금");
  newParams.put("toUserName", "김군");
  //{companyCode=LG01, langSet=ko, acctNm=받을어음, toUserName=김군, loginUserId=70399}
  Map<String, Object> newIntentParam = parameterRestValidatorTest(url, newParams);
  
  System.out.println("newIntentParam:"+newIntentParam);
  
 }

 
}
