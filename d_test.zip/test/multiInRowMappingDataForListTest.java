
package com.lgcns.vpadmin.intent;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class multiInRowMappingDataForListTest {

	public static class  Element {
		  private String type;
		  private String id;
		  private String title;
		  private String actionType;
		  private String action;
		  private String subtitle;
		  private String descriptions;
		  private String text;
		  private String value;
		  private String classNames;
		  private String unit;
		  private String amount;
		  private String actiontype;
		  private int popupWidth;
		  private int popupHeight;
		  private String imageUrl;
		  
		  /**
			 * Backend Proxy 에서 실행된 후의 수신된 Result
			 */
			private List<Map<String, Object>> actionResult;
		
		  
		  private Map<String, Object> additionalProperties;
		 
		  public String getType() {
		   return type;
		  }
		 
		  public void setType(String type) {
		   this.type = type;
		  }
		 
		  public String getId() {
		   return id;
		  }
		 
		  public void setId(String id) {
		   this.id = id;
		  }

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}

		public String getActionType() {
			return actionType;
		}

		public void setActionType(String actionType) {
			this.actionType = actionType;
		}

		public String getAction() {
			return action;
		}

		public void setAction(String action) {
			this.action = action;
		}

		public Map<String, Object> getAdditionalProperties() {
			return additionalProperties;
		}

		public void setAdditionalProperties(Map<String, Object> additionalProperties) {
			this.additionalProperties = additionalProperties;
		}

		public String getSubtitle() {
			return subtitle;
		}

		public void setSubtitle(String subtitle) {
			this.subtitle = subtitle;
		}

		public String getDescriptions() {
			return descriptions;
		}

		public void setDescriptions(String descriptions) {
			this.descriptions = descriptions;
		}

		public String getText() {
			return text;
		}

		public void setText(String text) {
			this.text = text;
		}

		public String getValue() {
			return value;
		}

		public void setValue(String value) {
			this.value = value;
		}

		

		public String getUnit() {
			return unit;
		}

		public void setUnit(String unit) {
			this.unit = unit;
		}

		

		public String getAmount() {
			return amount;
		}

		public void setAmount(String amount) {
			this.amount = amount;
		}

		public String getActiontype() {
			return actiontype;
		}

		public void setActiontype(String actiontype) {
			this.actiontype = actiontype;
		}

		public String getClassNames() {
			return classNames;
		}

		public void setClassNames(String classNames) {
			this.classNames = classNames;
		}

		public int getPopupWidth() {
			return popupWidth;
		}

		public void setPopupWidth(int popupWidth) {
			this.popupWidth = popupWidth;
		}

		public int getPopupHeight() {
			return popupHeight;
		}

		public void setPopupHeight(int popupHeight) {
			this.popupHeight = popupHeight;
		}

		public String getImageUrl() {
			return imageUrl;
		}

		public void setImageUrl(String imageUrl) {
			this.imageUrl = imageUrl;
		}

		public List<Map<String, Object>> getActionResult() {
			return actionResult;
		}

		public void setActionResult(List<Map<String, Object>> actionResult) {
			this.actionResult = actionResult;
		}

		

		

		}

	/**
	 * data 의 null 유무를 검사하고 
	 * @param data
	 * @return
	 */
	 public static  String convertToString (Object data) {
		
		if (data == null) {
			return null;
		}
		
		String result = null;
		
		if ( data instanceof String ) {
			result = (String) data;
		}
		else if (data instanceof Integer) {
			Integer tmp = (Integer) data;
			result = tmp.toString();
		}
		else if (data instanceof Long) {
			Long tmp = (Long) data;
			result = tmp.toString();
		}
		else if (data instanceof Float) {
			Float tmp = (Float) data;
			result = tmp.toString();
		}
		else if (data instanceof Double) {
			Double tmp = (Double) data;
			result = tmp.toString();
		}
		else {
			result = data.toString();
		}
		
		return result;
	}
	
	/**
	 * Element Action 중에서 변환해야할 변수를 실 데이터로 변환함<br/>
	 * (ex> ${AAA} 자산입니다.  ==> 1234567 자산입니다.), 단 AAA가 parameter data에 1234567로 정의되어 있어야 함.
	 * @param action
	 * @param data
	 * @return
	 */
	 public static  String makeActionValue_12 (String action, Map<String, Object> data) {
		
		if ( !StringUtils.hasText(action) || (data == null) || (data.isEmpty()) ) {
			return action;
		}
		
		String newAction = action;
		
		int sPos = action.indexOf("${");
		int ePos = -1;
		
		String key = null, keyTemp = null;
		Object value = null;
		
		while (sPos > -1) {
			ePos = action.indexOf("}", sPos);
			
			if ( (ePos <= -1) || (sPos <= -1) ) {
				break;
			}
			else {
				//keyList.add(action.substring(sPos, ePos+1));
				key = action.substring(sPos, ePos+1);
				if ( StringUtils.hasText(key) && (key.length() > 3) ) {
					keyTemp = key.substring(2, key.length()-1);
					keyTemp = keyTemp.trim();
					
					value = data.get(keyTemp);
					//System.out.println("["+keyTemp+"],["+value+"]");
					
					if (value != null) {
						newAction = newAction.replace(key, value.toString());
					}
				}
				
				sPos = action.indexOf("${", sPos+1);
			}
		}
		
		System.out.println("==="+newAction+"===");
		return newAction;
	}
	
	/**
	 * Mapper 에 설정 정보에 따라 Map 에서 값을 조회하여 Element 값을 만듬
	 * @param data
	 * @param strData
	 * @return
	 */
	 public static  String stringMapper ( Map<String, Object> data, String strData ) {
		//####data:{전월=102, 누적=100, 당월=101}
 		//####strData:투입률은 누적 : {$누적$}%, 당월 : {$당월$}%, 전월 : {$전월$}% 입니다.
		String resultStr = new String(strData);
		List<String> keyList = new ArrayList<String>();
				
		int limitPos = strData.length()-1;
		int startPos = 0, endPos = 0;
		
		//Key 값을 가져옴
		while (true) {
			startPos = strData.indexOf("{$", startPos);
			
			if (startPos < 0) {
				break;
			}
			else {
				endPos = strData.indexOf("$}", startPos);
				
				if ( (endPos < 0) || (endPos+1 > limitPos) ) {
					break;
				}
				else {
					String temp = (endPos+1 == limitPos) ? strData.substring(startPos) : strData.substring(startPos, endPos+2);
					keyList.add(temp);
					startPos = endPos;
				}
			}
		}
		
		//strData mapping
		if ( !keyList.isEmpty() ) {
			String mapValue = null;
			String mapKey = null;
			for ( String key : keyList ) {
				mapKey = key.substring(2, key.length()-2).trim();
				
				if ( StringUtils.isEmpty(mapKey) || !data.containsKey(mapKey) ) {
					//값이 없는 경우 빈문자열로 처리함
					resultStr = resultStr.replace(key,"");
					strData = strData.replace(key,"");
				}
				else {
					mapValue = convertToString( data.get(mapKey) );
					
					if ( !StringUtils.isEmpty(mapValue) ) {
						resultStr = resultStr.replace(key, mapValue);
					} else {//값이 없는 경우 빈문자열로 처리함
						resultStr = resultStr.replace(key,"");
						strData = strData.replace(key,"");
					}
				}
			}
		}
		else {
			resultStr = (data.get(strData) != null) ?  convertToString(data.get(strData)) : "";
		}
		
		return ( (resultStr == null) || (resultStr.length() <= 0) ) ? strData : resultStr;
	}
	 
	 
	public static void main(String[] args) {
		
		String jsonMapper=" {     "
				+"         \"appendMessage\":\" {$MONTHLY_TEXT$}월 급상여 현황은 다음과 같습니다.\",    "
				+" 		   \"noResultMessage\":\"{$MONTHLY_TEXT$}월 급여현황에 대해 조회된 결과가 없습니다.\",    "
				+"         \"mappers\":[    "
				+"                 {    "
				+"                         \"title\":\"{$MONTHLY_PAYMENT_LABEL$}\",    "
				+"                         \"amount\":\"{$MONTHLY_PAYMENT$}\",    "
				+"                         \"unit\":\"원\"    "
				+"                 },    "
				+"                 {    "
				+"                         \"title\":\"{$TAX_DEDUCTIONS_LABEL$}\",    "
				+"                         \"amount\":\"{$TAX_DEDUCTIONS$}\",    "
				+"                         \"unit\":\"원\"    "
				+"                 },    "
				+"                 {    "
				+"                         \"title\":\"{$DEDUCTED_PAYMENT_LABEL$}\",    "
				+"                         \"amount\":\"{$DEDUCTED_PAYMENT$}\",    "
				+"                         \"unit\":\"원\"    "
				+"                 }    "
				+"         ]    "
				+" }    ";
		
		List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>();
		
		Map<String, Object> item1 = new HashMap<>();
		item1.put("inquiryId", "5ae07763452d3865b82a28a4");
		item1.put("intentId", "INT75b2f9f963b6455682d2ebf70ff88eb0");
		item1.put("tenantId", "gsenc");
		
		item1.put("actionId", "ACT64681402010b493aba3aebf006095bce");
		item1.put("successYn", "Y");
		item1.put("description", "성공");
		
		item1.put("actionMessage", "decrypted");
		item1.put("mapKey", "c10344ca9437e5980beb012201293ae6");
		item1.put("description", "성공");
		 
		List<Map<String, Object>> actionResult= new ArrayList<Map<String, Object>>();
		Map<String, Object> item2 = new HashMap<>();
		item2.put("MONTHLY_TEXT", "11");
		item2.put("MONTHLY_PAYMENT_LABEL", "지급액");
		item2.put("MONTHLY_PAYMENT", "5,975,000");
		
		item2.put("TAX_DEDUCTIONS_LABEL", "공제액");
		item2.put("TAX_DEDUCTIONS", "816,738");
		
		item2.put("DEDUCTED_PAYMENT_LABEL", "차감지급액");
		item2.put("DEDUCTED_PAYMENT", "5,158,262");
		actionResult.add(item2);
		
		item1.put("actionResult", actionResult);
		
		dataList.add(item1);
		
		
		
		try {
			List<Element> elemList = new ArrayList<Element>();
			//Mapper Data 파싱하기
	        ObjectMapper mapper = new ObjectMapper();
	        JsonNode root = mapper.readTree(jsonMapper); // <=== Json String 으로 대체
	        JsonNode node = root.path("mappers");
	        JsonNode nodeMessage = root.path("appendMessage");
	        
	        if (node.isArray()) {
            	
            	//Activity Message 에 추가되는 Message
            	String appendMessage = (nodeMessage != null) ? nodeMessage.asText() : null;
            	
            	int size = node.size();
            	//int positionData = 0;
            	
            	String titleData = null;
            	String subtitleData = null;
            	String descriptionsData = null;
            	String textData = null;
            	String valueData = null;
            	String classNamesData = null;
            	String unitData = null;
            	String imageUrlData = null;
            	String amountData = null;
            	String actionData = null;
            	String actionTypeData = null;
            	//String idData = null;
            	String additionalData = null;
            	String popupWidth = null;
            	String popupHeight = null;
            	
            	
            	boolean isFirstRow = true;
            	//List<Map<String, Object>> proxyResultSet = dataList.get(index)
            	//반환된 데이터 개수 만큼 반복
            	for ( Map<String, Object> data : actionResult ) {
            	//for ( Map<String, Object> data : dataList ) {
            		
            		//Activity Message 에 추가되는 Message Mapping
            		if ( isFirstRow && !StringUtils.isEmpty(appendMessage) ) {
            			
            			//{$SYSTEM_RESULT_COUNT$} --> 결과 개수 처리, MultiRow는 공백으로 처리함
            			appendMessage = appendMessage.replace("{$SYSTEM_RESULT_COUNT$}", "");
            			
            			isFirstRow = false;
            			String mappingMessage = stringMapper(data, appendMessage);
            			
            			/*if (  StringUtils.isEmpty(activity.getMessage()) ) {
            				activity.setMessage(mappingMessage);
            			}
            			else {
            				StringBuffer buf = new StringBuffer(activity.getMessage());
            				buf.append(mappingMessage);
            				activity.setMessage(buf.toString());
            			}*/
            		}
            		
            		System.out.println("############size:"+size);
            		for (int j = 0; j < size; j++) {
            			
            			titleData = node.get(j).path("title").asText();
    	            	subtitleData = node.get(j).path("subtitle").asText();
    	            	descriptionsData = node.get(j).path("description").asText();
    	            	textData = node.get(j).path("text").asText();
    	            	valueData = node.get(j).path("value").asText();
    	            	classNamesData = node.get(j).path("classNames").asText();
    	            	unitData = node.get(j).path("unit").asText();
    	            	imageUrlData = node.get(j).path("imageUrl").asText();
    	            	amountData = node.get(j).path("amount").asText();
    	            	actionData = node.get(j).path("action").asText();
    	            	actionTypeData = node.get(j).path("actionType").asText();
                    	//idData = node.get(0).path(CommonCode.ELEMENT_ID).asText();
    	            	additionalData = node.get(j).path("additionnal").asText();
    	            	popupWidth = node.get(j).path("popupWidth").asText();
    	            	popupHeight = node.get(j).path("popupeight").asText();
	            		//positionData = node.get(j).path("position").asInt();
    	            	
    	            	System.out.println("############titleData:"+titleData+",amountData:"+amountData);
			            
		            	Element element = new Element();
	            		
		            	String titleDataTest=stringMapper(data, titleData);
		            	
		            	System.out.println("############data:"+data);
		            	
		            	System.out.println("############titleDataTest:"+titleDataTest);
		            	
		            	element.setTitle(stringMapper(data, titleData));
	            		element.setSubtitle(stringMapper(data, subtitleData));
	            		element.setDescriptions(stringMapper(data, descriptionsData));
	            		element.setText(stringMapper(data, textData));
	            		element.setValue(stringMapper(data, valueData));
	            		element.setClassNames(stringMapper(data, classNamesData));
	            		element.setUnit(stringMapper(data, unitData));
	            		element.setImageUrl(stringMapper(data, imageUrlData));
	            		element.setAmount(stringMapper(data, amountData));
	            		element.setActionType(actionTypeData);
	            		element.setAction(stringMapper(data, actionData));
	            		
	            		element.setPopupWidth( ( StringUtils.isEmpty(popupWidth) ) ? 0 : Integer.parseInt(popupWidth) );
	            		element.setPopupHeight( ( StringUtils.isEmpty(popupHeight) ) ? 0 : Integer.parseInt(popupHeight) );
	            		
	            		System.out.println("############element.getTitle:"+element.getTitle()+",element.getAmount:"+element.getAmount());
	            		
	            		if ( data.containsKey(additionalData) ) {
	    					Object tempMap = data.get(additionalData);
	    					
	    					if ( tempMap instanceof Map) {
	    						element.setAdditionalProperties((Map<String, Object>)tempMap);
	    					}
	    				}
		            	
	            		
	            		//Action 을 비워두면 안됨, Client에서 Error 남
	    				if ( !StringUtils.hasText(element.getAction()) ) {
	    					element.setAction("action");
	            		}
	    				
	    				elemList.add(element);
	            	}
	            	
            	}
            	
            }
            else if ( nodeMessage != null ) {
            	//Activity Message 에 추가되는 Message
            	String appendMessage = (nodeMessage != null) ? nodeMessage.asText() : null;
            	
            	Map<String, Object> data = null;
            	int size = dataList.size();
            	
            	if ( (size > 0) && (!StringUtils.isEmpty(appendMessage)) ) {
            		
            		data = dataList.get(0);
            		
            		//{$SYSTEM_RESULT_COUNT$} --> 결과 개수 처리, MultiRow는 공백으로 처리함
        			appendMessage = appendMessage.replace("{$SYSTEM_RESULT_COUNT$}", "");
        			
            		//Activity Message 에 추가되는 Message Mapping
        			String mappingMessage = stringMapper(data, appendMessage);
        			/*if (  StringUtils.isEmpty(activity.getMessage()) ) {
        				activity.setMessage(mappingMessage);
        			}
        			else {
        				StringBuffer buf = new StringBuffer(activity.getMessage());
        				buf.append(mappingMessage);
        				activity.setMessage(buf.toString());
        			}*/
            	}
            }
	      //  elemList.stream().forEach(action);
		} catch (Exception e) {
			e.printStackTrace();
		}
        
	}

	
}

