
package com.lgcns.vpa.security.user.dao;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.lgcns.vpa.dialog.util.JsonConverter;




	
public class createResponceActivityForNoneUriTest {

	public static  class Button  {

		 private static final long serialVersionUID = 4220461820168818969L;
		 
		   /**
		    * 버튼유형
		       */
		   private String type;

		   /**
		    * 버튼 제목
		    */
		   private String title;

		   // 액션정보
		   
		   /**
		    * 액션 유형 (link: 링크, inquiry: 인텐트처리)
		      */
		   private String actionType;
		   
		   /**
		    * 액션 connect 유형 (pc: pc, mobile: mobile)
		    */
		   private String actionConnectType;
		   
		   /**
		    * 액션
		    */
		   private String action;
		       
		   /**
		    * 액션 파라미터
		    */
		   private Map<String, Object> actionParams;
		   
		   /**
		    * 아이콘 (Font Awesome class)
		    */
		   private String icon;
		   
		   private int popupWidth;
		   
		   private int popupHeight;

		   public String getType() {
		       return type;
		   }

		   public void setType(String type) {
		       this.type = type;
		   }

		   public String getTitle() {
		       return title;
		   }

		   public void setTitle(String title) {
		       this.title = title;
		   }

		   public String getActionType() {
		       return actionType;
		   }

		   public void setActionType(String actionType) {
		       this.actionType = actionType;
		   }

		   public void setAction(String action) {
		       this.action = action;
		   }

		   public String getAction() {
		       return action;
		   }

		   public Map<String, Object> getActionParams() {
		       return actionParams;
		   }

		   public void setActionParams(Map<String, Object> actionParams) {
		       this.actionParams = actionParams;
		   }

		   public String getIcon() {
		       return icon;
		   }

		   public void setIcon(String icon) {
		       this.icon = icon;
		   }

		   public int getPopupWidth() {
		       return popupWidth;
		   }

		   public void setPopupWidth(int popupWidth) {
		       this.popupWidth = popupWidth;
		   }

		   public int getPopupHeight() {
		       return popupHeight;
		   }

		   public void setPopupHeight(int popupHeight) {
		       this.popupHeight = popupHeight;
		   }

		 public String getActionConnectType() {
		  return actionConnectType;
		 }

		 public void setActionConnectType(String actionConnectType) {
		  this.actionConnectType = actionConnectType;
		 }
		}

	public static class  Element {
		  private String type;
		  private String id;
		  private String title;
		  private String actionType;
		  private String action;
		 
		  public String getType() {
		   return type;
		  }
		 
		  public void setType(String type) {
		   this.type = type;
		  }
		 
		  public String getId() {
		   return id;
		  }
		 
		  public void setId(String id) {
		   this.id = id;
		  }

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}

		public String getActionType() {
			return actionType;
		}

		public void setActionType(String actionType) {
			this.actionType = actionType;
		}

		public String getAction() {
			return action;
		}

		public void setAction(String action) {
			this.action = action;
		}

		}

		 public static class Attachment {

		  private String attachId;
		  private String attachName;
		  private String type;
		  private String templateType;
		  
		 
		  private List<Element> elements;
		 
		  public String getAttachId() {
		   return attachId;
		  }
		 
		  public void setAttachId(String attachId) {
		   this.attachId = attachId;
		  }
		 
		  public String getAttachName() {
		   return attachName;
		  }
		 
		  public void setAttachName(String attachName) {
		   this.attachName = attachName;
		  }
		 
		  public List<Element> getElements() {
		   return elements;
		  }
		 
		  public void setElements(List<Element> elements) {
		   this.elements = elements;
		  }

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getTemplateType() {
			return templateType;
		}

		public void setTemplateType(String templateType) {
			this.templateType = templateType;
		}

		}

		 public static class Activity {

		  private String replyToId;
		  private String tempId;
		  private String type;
		  private String message;
		  private String senderType;
		  private Map<String, Object> additionalProperties;
		  private List<Attachment> attachments;
		  /**
		   * 버튼 리스트
		   */
		  private List<Button> buttons;
		 
		  public String getReplyToId() {
		   return replyToId;
		  }
		 
		  public void setReplyToId(String replyToId) {
		   this.replyToId = replyToId;
		  }
		 
		  public String getTempId() {
		   return tempId;
		  }
		 
		  public void setTempId(String tempId) {
		   this.tempId = tempId;
		  }
		 
		  public String getType() {
		   return type;
		  }
		 
		  public void setType(String type) {
		   this.type = type;
		  }
		 
		  public Map<String, Object> getAdditionalProperties() {
		   return additionalProperties;
		  }
		 
		  public void setAdditionalProperties(Map<String, Object> additionalProperties) {
		   this.additionalProperties = additionalProperties;
		  }
		 
		  public Activity addAdditionalProperty(String key, Object value) {
		   if (this.additionalProperties == null) {
		    this.additionalProperties = new HashMap<>();
		   }
		   this.additionalProperties.put(key, value);
		   return this;
		  }
		 
		  public List<Attachment> getAttachments() {
		   return attachments;
		  }
		 
		  public void setAttachments(List<Attachment> attachments) {
		   this.attachments = attachments;
		  }
		  
		  //BUTTON START
		  public List<Button> getButtons() {
		   return buttons;
		  }
		 
		  public void setButtons(List<Button> buttons) {
		   this.buttons = buttons;
		  }
		  
		  public Activity addButton(Button button) {
		   if (this.buttons == null) {
		    this.buttons = new ArrayList<Button>();
		   }
		   this.buttons.add(button);
		   return this;
		  }
		  
		  public Activity addButton(int position, Button button) {
		   if (this.buttons == null) {
		    this.buttons = new ArrayList<Button>();
		   }
		   
		   position = (position >= this.buttons.size()) ? this.buttons.size() : position;
		   position = (position < 0) ? 0 : position; 
		  
		   this.buttons.add(position, button);
		   return this;
		  }
		  //BUTTON END

		public String getMessage() {
			return message;
		}

		public void setMessage(String message) {
			this.message = message;
		}

		public String getSenderType() {
			return senderType;
		}

		public void setSenderType(String senderType) {
			this.senderType = senderType;
		}

		}


	
	public static void main(String[] args) {
		

		String jsonMapper1= "{ "
				+ "	\"type\":\"message\", "  
				+ "	\"message\":\"\", " 
				+ "	\"senderType\":\"bot\", " 
				+ "	\"attachments\": [ " 
				+ "		{ "
				+ "			\"type\":\"template\", "
				+ "			\"templateType\":\"list\", "
				+ "			\"elements\":["
				+ "				{"
				+ "					\"title\": \"LG사이언스파크 주차\","
				+ "					\"actionType\": \"inquiry\","
				+ "					\"action\": \"LG사이언스파크 주차\""
				+ "				},"
				+ "				{"
				+ "					\"title\": \"LG사이언스파크 휴일 무료 주차\","
				+ "					\"actionType\": \"inquiry\","
				+ "					\"action\": \"LG사이언스파크 휴일 무료 주차\""
				+ "				},"
				+ "				{"
				+ "					\"title\": \"외부인 방문자(고객) 주차\","
				+ "					\"actionType\": \"inquiry\","
				+ "					\"action\": \"외부인 방문자 주차\""
				+ "				}"
				+ "			] "
				+ "		} "
				+ "	], "
				+ "	\"buttons\":[] "
				+ "}";
		
		String jsonMapper="{\"mappers\":[ "
				+ "		{ "
				+ "			\"title\":\"투입률은 누적 : {$누적$}%, 당월 : {$당월$}%, 전월 : {$전월$}% 입니다.\",  "
				+ "			\"subtitle\":\"[개인투입률]\",   "
				+ "			\"actionType\":\"INQUIRY\"   "
				+ "		} "
				+ "	]  "
				+ " }";
		
		
		 Activity resultActivity = new Activity();
		try {
			
			JsonConverter<Activity> jc = new JsonConverter<Activity>();
			resultActivity = jc.jasonStringToObject(jsonMapper1, Activity.class);
			Activity resultActivity2 = new ObjectMapper().readValue(jsonMapper1, Activity.class);
			System.out.println("####:"+resultActivity);
			System.out.println("####:"+resultActivity.getType());
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
	}

	
}

