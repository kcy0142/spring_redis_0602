package com.example.queue;

public interface MessagePublisher {

    void publish(final String message);
}
