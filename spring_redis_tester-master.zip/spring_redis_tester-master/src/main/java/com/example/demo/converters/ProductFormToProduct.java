package com.example.demo.converters;

import com.example.demo.commands.ProductForm;
import com.example.demo.domain.Product;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/**
 * Created by jt on 1/10/17.
 */
@Component
public class ProductFormToProduct implements Converter<ProductForm, Product> {

    @Override
    public Product convert(ProductForm productForm) {
        Product product = new Product();
        if (productForm.getId() != null  && !StringUtils.isEmpty(productForm.getId())) {
            product.setId(productForm.getId());
           // product.setId(productForm.getLevel()+":"+productForm.getBranchName());
        }else{
        	  product.setId(productForm.getLevel()+":"+productForm.getBranchName());
        }
        product.setDescription(productForm.getDescription());
        product.setPrice(productForm.getPrice());
        
        product.setLevel(productForm.getLevel());
        product.setBranchName(productForm.getBranchName());
        product.setModel(productForm.getModel());
        
        product.setImageUrl(productForm.getImageUrl());
        return product;
    }
}
