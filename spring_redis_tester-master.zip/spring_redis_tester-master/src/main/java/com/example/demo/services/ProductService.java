package com.example.demo.services;

import com.example.demo.commands.ProductForm;
import com.example.demo.domain.Car;
import com.example.demo.domain.Person;
import com.example.demo.domain.Product;

import java.util.List;
import java.util.Map;


public interface ProductService {

    List<Product> listAll();

    Product getById(String id);

    Product saveOrUpdate(Product product);
    
    Product saveOrUpdateAll(Product product);

    void delete(String id);

    Product saveOrUpdateProductForm(ProductForm productForm);
    
    
    public List<Product> findSearchAll(Product product);
    
    public Map<Object, Object> findSearch(Product product);
}
