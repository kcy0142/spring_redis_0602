package com.example.demo.services.impl;

import com.example.demo.commands.ProductForm;
import com.example.demo.converters.ProductFormToProduct;
import com.example.demo.domain.Person;
import com.example.demo.domain.Product;
import com.example.demo.repositories.ProductRepository;
import com.example.demo.services.ProductService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import java.util.List;
import java.util.Map;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

//import org.apache.shiro.codec.Base64;


@Service
public class ProductServiceImpl implements ProductService {

    private ProductRepository productRepository;
    private ProductFormToProduct productFormToProduct;
    

	@Autowired
	private RedisTemplate redisTemplate;

    @Autowired
    public ProductServiceImpl(ProductRepository productRepository, ProductFormToProduct productFormToProduct) {
        this.productRepository = productRepository;
        this.productFormToProduct = productFormToProduct;
    }


    @Override
    public List<Product> listAll() {
        List<Product> products = new ArrayList<>();
        productRepository.findAll().forEach(products::add); //fun with Java 8
       
        return products;
    }

    @Override
    public Product getById(String id) {
    	System.out.println("##########find:"+id);
        return productRepository.findOne(id);
    }

    @Override
    public Product saveOrUpdate(Product product) {
    
        productRepository.save(product);
        return product;
    }
    
    @Override
    public Product saveOrUpdateAll(Product product) {
    
        productRepository.save(product);
        
        Product p1=new Product();
        BigDecimal b1 = new BigDecimal("300000");
        p1.setId("products:1:홈플러스 금천점");
        p1.setLevel("1");
        p1.setBranchName("홈플러스 금천점");
        p1.setModel("tv1");
        p1.setPrice(b1);
        p1.setDescription("tv1");
        
        Product p2=new Product();
        BigDecimal b2 = new BigDecimal("400000");
        p2.setId("products:1:금천본점");
        p2.setLevel("1");
        p2.setBranchName("금천본점");
        p2.setModel("tv2");
        p2.setPrice(b2);
        p2.setDescription("tv2");
        
        
        Product p3=new Product();
        p3.setId("products:2:홈플러스 금천점");
        p3.setLevel("2");
        p3.setBranchName("홈플러스 금천점");
        p3.setModel("monitor1");
        p3.setPrice(b1);
        p3.setDescription("monitor1");

        Product p4=new Product();
        p4.setId("products:2:금천본점");
        p4.setLevel("2");
        p4.setBranchName("금천본점");
        p4.setModel("monitor2");
        p4.setPrice(b2);
        p4.setDescription("monitor2");
        
        Product ap3=new Product();
        Product ap4=new Product();
        ap3.setId("products:3:강남본점");
        ap3.setLevel("3");
        ap3.setBranchName("강남본점");
        ap3.setModel("선풍기1");
        ap3.setPrice(b1);
        ap3.setDescription("선풍기1");

        ap4.setId("products:3:논현본점");
        ap4.setLevel("3");
        ap4.setBranchName("논현본점");
        ap4.setModel("냉장고");
        ap4.setPrice(b2);
        ap4.setDescription("냉장고");
        
        productRepository.save(p1);
        productRepository.save(p2);
        productRepository.save(p3);
        productRepository.save(p4);
        productRepository.save(ap3);
        productRepository.save(ap4);
        return product;
    }

    @Override
    public void delete(String id) {
        productRepository.delete(id);

    }

    @Override
    public Product saveOrUpdateProductForm(ProductForm productForm) {
        Product savedProduct = saveOrUpdate(productFormToProduct.convert(productForm));

        return savedProduct;
    }
    
    @Override
    public List<Product> findSearchAll(Product product){
    	
    	System.out.println("#####search getLevel:"+product.getLevel());
    	System.out.println("#####search getBranchName:"+product.getBranchName());
    	
    	String level=product.getLevel();
    	String branchName=product.getBranchName();
    	
    	
    	//String key="products:1:aa";
    	String workKey="products:"+level+":*"+branchName+"*";
    	String workKey1="2:논현";
    	String workKey2="products:2:논현";
    	String workKey3="2:논현";
    	ScanOptions options = ScanOptions.scanOptions().match(workKey).count(100).build();

    	Product p=getById(workKey1);
    //	Product p=(Product) redisTemplate.opsForValue().get(workKey1);
    	System.out.println("######sample:"+p.getBranchName());
    	
    	
    	//Product pa=(Product) redisTemplate.opsForValue().get(workKey2,workKey3);
    	
    	
    	// Map<Object,Object>pp=redisTemplate.opsForHash().entries(workKey2);
    	
    		
    	
    	//redisTemplate.opsForHash().get(arg0, arg1)
    	/*Cursor carList2 = redisTemplate.opsForHash().scan(0, options);
    	while (carList2.hasNext()) {
            System.out.println(new String((byte[]) carList2.next()));
        }*/
    	
    	//
    	//https://findusages.com/search/org.springframework.data.redis.connection.RedisConnection/scan$1
    	ScanOptions options1 = ScanOptions.scanOptions().build();
    	RedisConnectionFactory factory = redisTemplate.getConnectionFactory();
    	RedisConnection conn = factory.getConnection();
    	Cursor<byte[]> cursor = conn.scan(options);
    	List<Product> result = new ArrayList<Product>();
    	while(cursor.hasNext()){
    		
    		/*Object value = getData(new String(cursor.next()));
    		if(value != null){
    			result.add(value);
    		}*/
    		String key=new String((byte[]) cursor.next());
    		System.out.println("####### key:"+key);
    		//Product p=(Product) redisTemplate.opsForValue().get(key);
    		//Object obj = redisTemplate.opsForValue().get(key);
    		//Product p=(Product)  redisTemplate.opsForHash().entries(key);
    		//System.out.println("####### key"+key+",p:"+p.getModel()+",sss:"+p.getBranchName());
    		//System.out.println("####### key:"+key);
    		Product pa=getById(key.replace("products:",""));
    		System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$:"+pa.getBranchName());
    		result.add(pa);
    	}
    	//
    	/*List<Object> listOfObjects = new ArrayList<>();
        Cursor<Entry<Object, Object>> cursorMap = redisTemplate.boundHashOps(SNAPSHOT_MODULE_KEY)
                .scan(ScanOptions.scanOptions().match(pattern).count(100).build());*/
    	
    	//Map<Object, Object> carList = redisTemplate.opsForHash().entries(P_KEY); 
		return result;
    }
    
  	private Object getData(Object key) {
  		// TODO Auto-generated method stub
  		Object obj = redisTemplate.opsForValue().get(key);
  		if(obj != null){
  			obj = deserialize(obj.toString());
  		}
  		return obj;
  	}
    
  	private static Object deserialize(String str) {  
        ByteArrayInputStream bis = null;  
        ObjectInputStream ois = null;  
        try {  
          //  bis = new ByteArrayInputStream(Base64.decode(str));  
            ois = new ObjectInputStream(bis);  
            return ois.readObject();  
        } catch (Exception e) {  
            throw new RuntimeException("deserialize session error", e);  
        } finally {  
            try {  
                ois.close();  
                bis.close();  
            } catch (IOException e) {  
                e.printStackTrace();  
            }  
  
        }  
    }  
    @Override
    public Map<Object, Object> findSearch(Product product){
    	
    	return redisTemplate.opsForHash().entries("vpa_Person:lgcns");
    	//return redisTemplate.opsForHash().entries(person.getOrganization()==null?"vpa_Person:lgcns":"vpa_Person:"+person.getOrganization());
    }
}
